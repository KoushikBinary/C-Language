#include <stdio.h>
int main(){
    int p,t,r,si;
    scanf("%d %d %d",&p,&t,&r);
    si=p*t*r/100;
    printf("%d",si);
}