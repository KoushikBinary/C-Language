#include <stdio.h>
int main(){
    float a,b,avg;
    scanf("%f %f",&a,&b);
    avg=(a+b)/2.0;
    printf("%.4f",avg);
}