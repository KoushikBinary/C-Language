#include <stdio.h>
int main(){
    float f,c;
    scanf("%f",&c);
    f=c*(1.8)+32;
    printf("%.2f",f);
}