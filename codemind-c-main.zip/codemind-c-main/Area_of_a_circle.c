
#include <stdio.h>
int main(){
    float r,a;
    scanf("%f",&r);
    a=3.14*r*r;
    printf("%.2f",a);
}
