#include <stdio.h>
int main(){
    int a,n;
    scanf("%d",&a);
    n=a*(a-3)/2;
    printf("%d",n);
}