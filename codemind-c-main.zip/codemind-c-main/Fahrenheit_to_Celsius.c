#include <stdio.h>
int main(){
    float f,c;
    scanf("%f",&f);
    c=(f-32)*(0.555555);
    printf("%.2f",c);
}